import { DuriTravelApp } from "./components/DuriTravelApp";

function App() {
  return <DuriTravelApp />;
}

export default App;
